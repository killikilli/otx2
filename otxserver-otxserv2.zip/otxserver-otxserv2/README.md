### What is OTX Server 2 Series
We are trying to create the perfect custom open tibia server.

### How Compile:
[Windows Tutorial](https://github.com/mattyx14/otxserver/wiki/Compilling-on-Windows) - [Linux Tutorial](https://github.com/mattyx14/otxserver/wiki/Compilling-on-Linux)