function onThankYou(cid, statementId)
	-- TODO :)
	return true
end