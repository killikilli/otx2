function onRaid()
	doBroadcastMessage("Broadcast from a raid script!")
	return true
end
